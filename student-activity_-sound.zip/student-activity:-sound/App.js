import * as React from 'react';
import { Text, View, Button, TouchableOpacity } from 'react-native';
import {Audio} from 'expo-av';

class SoundButton extends React.Component {
    playSound = async () => {
   await Audio.Sound.createAsync(
   {uri: 'https://soundbible.com/mp3/Buzzer-SoundBible.com-188422102.mp3'},
   {shouldPlay: true}  
   );
  }

  render() {
    return (
     <TouchableOpacity style={{
       marginLeft:100,
       borderWidth:2,
       borderColor:'aqua',
       alignItems:'center',
       width:200,
       height:200,
       backgroundColor:'lightblue',
       borderRadius:200
     }}
     onPress={this.playSound}>
     
     <Text style={{
       textAlign:'center',
       marginTop:80,
       fontSize:35
     }}>Press me</Text> 
     </TouchableOpacity>
    );
  }
}

export default class App extends React.Component {
  render() {
    return (
      <View style={{marginTop:200}}>
        <SoundButton />
      </View>
    );
  }
}


